# Lead Recovery: SMS-first missed-call assistant for tradies

When a tradie misses a call, the caller gets a text within seconds. An AI assistant asks what they need, one question at a time, captures the job, suburb, urgency, name and best callback time, then texts the tradie a summary with one-tap links to offer callback times or decline. Emergencies trigger an immediate phone call to the tradie. Landlines and withheld numbers go to voicemail with the transcript texted to the tradie.

## What's in the box

```
lead-recovery/
├── README.md                         this guide
├── .env.example                      your settings (copy to .env)
├── prepare.sh                        fills your settings into the files below
├── sql/
│   ├── 01_schema.sql                 tables + ALL business logic as SQL functions
│   ├── 02_seed.template.sql          config + your first tradie
│   └── 03_admin_queries.sql          funnel report, conversation viewer, resets
├── n8n/
│   └── lead-recovery.workflow.json   one workflow, 22 nodes, import as-is
└── test/
    ├── sql_smoke_test.sql            15 end-to-end checks, rolls back after
    └── simulate.sh                   fake Twilio webhooks for testing with curl
```

## How it works

All decisions live in Postgres functions. n8n is deliberately thin: it receives a Twilio webhook, calls one Supabase RPC function, and sends whatever "actions" (SMS or voice calls) the function returns through Twilio. This means you can unit-test the logic in SQL, change behaviour without touching n8n, and later swap n8n for anything else without rewriting the brain.

| Trigger | n8n path | SQL function | What happens |
|---|---|---|---|
| Diverted missed call | `rl-voice-<secret>` | `fn_intake` | Plays a short message, texts the caller (or sends landlines to voicemail) |
| Voicemail transcript | `rl-vm-<secret>` | `fn_voicemail` | Texts the transcript to the tradie |
| Customer texts | `rl-sms-<secret>` | `fn_inbound_sms` → Claude → `fn_apply_llm` | Qualifies the job, notifies the tradie, handles STOP and slot picks |
| Tradie taps a link | `rl-t-<secret>` | `fn_tradie_action` | Offers 3 callback slots, declines politely, or records won/lost |
| Every 5 minutes | schedule | `fn_due_actions` | Nudges, reminders, partial leads, 15-min callback heads-up, won/lost check |

## Before you start

You need accounts for four things. All have free tiers or trials good enough for a POC.

1. **Supabase** (database). Create a project and choose the **Sydney** region so data stays in Australia.
2. **n8n**, either n8n Cloud or self-hosted, reachable on a public HTTPS URL (Twilio must be able to reach it). Version 1.30 or later recommended.
3. **Twilio** with an **Australian mobile number** that supports SMS and voice. Twilio requires a regulatory bundle (proof of an Australian address) before it will issue AU numbers, so start this first; approval can take a day or more.
4. **Anthropic API key** from console.anthropic.com. The default model is `claude-haiku-5-5`, chosen for speed and cost. You can change it in `app_config.llm_model`.

You also need a second mobile phone to play "the customer" while testing, and a terminal with `bash`, `sed` and `curl` (macOS, Linux, or WSL on Windows).

---

## Step 1: Create the database

1. In Supabase, open **SQL Editor**, then **New query**.
2. Paste the whole of `sql/01_schema.sql` and click **Run**. It is safe to re-run later after you edit it.
3. Check **Table Editor**: you should see `app_config`, `tenants`, `known_contacts`, `opt_outs`, `call_events`, `leads` and `messages`.

The script enables row-level security on every table and restricts all functions to the `service_role` key, so the public `anon` key can't read or call anything.

## Step 2: Fill in your settings

```bash
cp .env.example .env
openssl rand -hex 16          # paste the output as WEBHOOK_SECRET
nano .env                     # fill in the other values
./prepare.sh
```

`prepare.sh` writes two files to `build/`: the workflow with your secret and Supabase URL baked in, and the seed SQL with your config. It also prints the two Twilio webhook URLs you'll need in Step 6.

## Step 3: Add your first tradie and run the tests

1. Open `build/02_seed.sql` and edit the tenant block: business name, owner's first name (used in every text), trade, the tradie's own mobile (where alerts go), service area, postcodes, business hours and any extra instructions for the assistant. For your own testing, put **your** mobile as `owner_mobile`.
2. Run `build/02_seed.sql` in the Supabase SQL editor.
3. Run `test/sql_smoke_test.sql` in the SQL editor. Open the **Messages/Notices** output and you should see 15 checks finishing with `ALL TESTS PASSED`. Everything is rolled back, so your data is untouched.

## Step 4: Create three credentials in n8n

In n8n go to **Credentials**, then **Add credential**.

**Supabase (service role).** Type: **Custom Auth**. Get the key from Supabase **Project Settings > API Keys** and keep it secret; it bypasses all security.

If your project shows the newer secret key (starts with `sb_secret_`):
```json
{ "headers": { "apikey": "sb_secret_xxxxxxxx" } }
```
If it shows the legacy `service_role` key (a long JWT starting with `eyJ`):
```json
{ "headers": { "apikey": "eyJ...", "Authorization": "Bearer eyJ..." } }
```
If your n8n version has no Custom Auth type, use **Header Auth** with name `apikey` for the new key type.

**Anthropic.** Type: **Header Auth**. Name: `x-api-key`. Value: your Anthropic API key.

**Twilio.** Type: **Basic Auth**. User: your Account SID (starts `AC`). Password: your Auth Token. Better practice: create a Twilio API Key and use its SID and secret here instead; the URLs still use your Account SID, which is already in the database.

## Step 5: Import and activate the workflow

1. In n8n: **Workflows > Add workflow**, then the **⋯** menu, **Import from File**, and choose `build/lead-recovery.workflow.json` (the one in `build/`, not `n8n/`).
2. Open each HTTP node and select a credential. There are nine:
   - `fn_intake`, `fn_voicemail`, `fn_inbound_sms`, `fn_apply_llm`, `fn_tradie_action`, `fn_due_actions` → **Supabase (service role)**
   - `Claude: qualify lead` → **Anthropic**
   - `Twilio: make call`, `Twilio: send SMS` → **Twilio**
3. Save, then toggle the workflow **Active**. The webhooks only respond on their production URLs once the workflow is active.

## Step 6: Point your Twilio number at n8n

In Twilio Console go to **Phone Numbers > Manage > Active numbers** and click your AU number.

- **Voice configuration**, "A call comes in": Webhook, `https://<n8n>/webhook/rl-voice-<secret>`, **HTTP POST**
- **Messaging configuration**, "A message comes in": Webhook, `https://<n8n>/webhook/rl-sms-<secret>`, **HTTP POST**

Use the exact URLs that `prepare.sh` printed. Save.

## Step 7: Test it end to end (no diverting yet)

Because the Twilio number only exists to catch missed calls, calling it directly behaves exactly like a missed call. Use your second phone as the customer.

1. **Missed call.** Call the Twilio number. You should hear a short Australian-voice message, the call hangs up, and within seconds you get the opener text.
2. **Qualify.** Reply as a customer would: "my hot water system is leaking". Answer the follow-up questions. After a few messages the assistant wraps up and your `owner_mobile` gets the lead summary with two links.
3. **Book.** Tap "Offer callback times". A confirmation page opens, and the customer phone gets three time slots. Reply `2`. Both phones get a confirmation.
4. **Emergency.** From a different number (or after resetting your test data), say "pipe burst, water everywhere". The owner phone should get an URGENT text and a phone call.
5. **Opt out.** Text `STOP`. You get one confirmation, and further texts are ignored. Text `START` to undo.
6. **Watch it work.** In n8n, **Executions** shows every run, node by node. In Supabase, run the queries in `sql/03_admin_queries.sql` to see leads, conversations and the funnel.

To test from a terminal without phoning, `./test/simulate.sh call +614YOURMOBILE` and `./test/simulate.sh sms +614YOURMOBILE "Blocked drain"` fire fake Twilio webhooks. The replies are real texts, so use your own number.

To reset a test phone, use the delete statements at the bottom of `sql/03_admin_queries.sql`.

## Step 8: Divert a tradie's mobile to the Twilio number

On the tradie's phone, these standard codes divert unanswered, busy and unreachable calls. Dial each one like a phone number, replacing the number with their Twilio number:

```
**61*+61480000000#     divert when not answered
**67*+61480000000#     divert when busy
**62*+61480000000#     divert when unreachable or switched off
##61#   ##67#   ##62#  cancel each one
```

Three things to check with every new tradie:

- **Carrier support.** These codes work on most Australian carriers, but some plans manage diversion through the carrier's app or voicemail settings instead. If a code fails, check with their carrier.
- **Caller ID.** Make one test call from another phone and confirm the opener text reaches *that* phone. If the carrier replaces the caller ID on diverted calls, the flow can't text the customer, and you'll need a different setup for that carrier.
- **Cost and voicemail.** Diverted calls may be charged on the tradie's plan, and diverting replaces their existing voicemail. Tell them upfront.

## Step 9: Onboarding a real tradie

For each new tradie: buy them a Twilio number, add a tenant row (copy the seed block), point the number's webhooks at the same two n8n URLs (the workflow routes by the number called, so one workflow serves every tradie), add their suppliers, family and regulars to `known_contacts` so they never get the auto-text, set up diversion, and do the Step 8 test call together. Tell them to save the Twilio number in their contacts as something like "Lead Assistant" so alerts are recognisable.

---

## Customising behaviour

You rarely need to touch n8n. Most changes are SQL:

- **What the assistant says and asks:** edit `_system_prompt()` in `01_schema.sql` and re-run the file. Per-tradie tweaks go in `tenants.extra_instructions`.
- **Opener, wrap-up and other fixed texts:** in `fn_intake`, `fn_apply_llm`, `fn_tradie_action` and `fn_due_actions`.
- **Timings and limits:** `update app_config set ...` for `max_bot_messages`, `nudge_after`, `tradie_reminder_after`, `slot_pick_timeout`, `close_after`, `repeat_call_window` and quiet hours (default no non-urgent texts 8pm to 8am).
- **Voice:** the `_say()` helper uses Twilio's `Polly.Olivia-Neural` Australian voice. If your account doesn't support it, change it to another voice from Twilio's text-to-speech list.
- **Business hours and slots:** `tenants.business_hours` controls callback slots (30-minute slots, spaced two hours apart, at least an hour from now).

## Troubleshooting

**No text after a missed call.** Check n8n Executions. If there's no execution, the Twilio webhook URL is wrong or the workflow isn't active. If `fn_intake` failed, check the Supabase credential. If it ran but `Twilio: send SMS` shows an error, read it: common causes are a Twilio trial account (it can only text verified numbers) or credentials.

**Caller hears "this number is not in service".** The `to` number didn't match a tenant. Check `tenants.twilio_number` is exactly the Twilio number in `+61...` format.

**The assistant never replies to texts.** Open the `Claude: qualify lead` node output in the execution. A 401 means the API key is wrong; a 404 or "model not found" means the model name in `app_config.llm_model` isn't available to your key. If Claude fails, the SQL deliberately falls back to sending the lead straight to the tradie, so customers are never left hanging.

**Links in the tradie's text show "not valid".** The webhook secret in `app_config` must match the one in the n8n webhook paths. Re-run `prepare.sh` and the seed if you changed it.

**Two replies to STOP.** Twilio may send its own opt-out confirmation as well. If so, delete the confirmation SMS in the STOP branch of `fn_inbound_sms`.

## Before you charge money: hardening checklist

The POC is functional and safe to trial, but tighten these before scaling:

1. **Validate Twilio signatures.** The secret webhook path stops casual abuse, but proper protection is checking the `X-Twilio-Signature` header. Add a Code node after each Twilio webhook (requires `NODE_FUNCTION_ALLOW_BUILTIN=crypto` on self-hosted n8n) or put a small validating proxy in front.
2. **Rapid double texts.** If a customer sends two messages within a second or two, both can trigger an LLM call and the customer may get two replies. A short debounce (a 5-second Wait node, then skip if a newer message exists) fixes it.
3. **Spam Act and privacy.** The opener identifies the business and includes an opt-out, and replies are to someone who just contacted the business, which is the safest ground. Still: publish a short privacy policy covering what you collect and why, keep opt-outs permanent, and get legal advice before any outbound marketing.
4. **Recording disclosure.** The voicemail greeting makes recording obvious. If you ever record live calls, Australian consent rules vary by state.
5. **MMS photos.** The system records photo links but doesn't forward images. Check whether your Twilio AU number supports MMS before advertising photo support.
6. **Monitoring.** Set an n8n error workflow to alert you on failures, and enable Supabase daily backups.
7. **Data retention.** Decide how long to keep conversations, and schedule a delete for older ones.

## Measuring the POC

Run `select * from v_funnel_weekly;` each week. Missed calls, texted, replied, qualified, callbacks booked and jobs won is the exact story you'll use to sell this: "Last month, 38 missed calls turned into 22 qualified leads and 9 won jobs." Two days after each lead, the tradie gets a one-tap "did you win it?" text, so the won/lost numbers fill themselves in.
