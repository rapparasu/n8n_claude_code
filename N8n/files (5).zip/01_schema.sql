-- =====================================================================
-- Lead Recovery (SMS-first missed-call assistant)
-- Postgres / Supabase schema + business logic
--
-- Design: all decisions live here as SQL functions. n8n only moves data:
-- Twilio webhook -> RPC function -> returns {twiml/html, actions[]} ->
-- n8n sends each action (SMS or voice call) through Twilio.
--
-- Run this whole file in the Supabase SQL editor. It is safe to re-run.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Tables
-- ---------------------------------------------------------------------

create table if not exists app_config (
  id                     int primary key default 1 check (id = 1),
  webhook_base_url       text not null,     -- e.g. https://n8n.example.com/webhook  (no trailing slash)
  webhook_secret         text not null,     -- same value baked into the n8n webhook paths
  twilio_account_sid     text not null,
  llm_model              text not null default 'claude-haiku-5-5',
  max_bot_messages       int  not null default 5,          -- assistant wraps up after this many texts
  nudge_after            interval not null default '30 minutes',
  tradie_reminder_after  interval not null default '60 minutes',
  slot_pick_timeout      interval not null default '3 hours',
  close_after            interval not null default '24 hours',
  repeat_call_window     interval not null default '4 hours',
  quiet_start_hour       int not null default 20,          -- no non-urgent texts from 8pm...
  quiet_end_hour         int not null default 8            -- ...until 8am (tenant local time)
);

create table if not exists tenants (
  id                 uuid primary key default gen_random_uuid(),
  business_name      text not null,
  owner_name         text not null,
  trade              text not null,
  twilio_number      text not null unique,        -- E.164, e.g. +61480000000
  owner_mobile       text not null,               -- E.164, where alerts go
  timezone           text not null default 'Australia/Sydney',
  service_area_desc  text,
  service_postcodes  text[] not null default '{}',
  business_hours     jsonb not null default
    '{"mon":["07:00","17:00"],"tue":["07:00","17:00"],"wed":["07:00","17:00"],"thu":["07:00","17:00"],"fri":["07:00","17:00"]}',
  extra_instructions text,
  active             boolean not null default true,
  created_at         timestamptz not null default now()
);

-- Numbers that should never get the auto-text (suppliers, family, regulars)
create table if not exists known_contacts (
  tenant_id  uuid not null references tenants(id) on delete cascade,
  phone      text not null,
  label      text,
  primary key (tenant_id, phone)
);

create table if not exists opt_outs (
  tenant_id  uuid not null references tenants(id) on delete cascade,
  phone      text not null,
  created_at timestamptz not null default now(),
  primary key (tenant_id, phone)
);

create table if not exists call_events (
  id           bigserial primary key,
  tenant_id    uuid not null references tenants(id) on delete cascade,
  caller_phone text,
  call_sid     text,
  outcome      text not null,      -- texted | repeat_call | voicemail:<reason>
  created_at   timestamptz not null default now()
);

create table if not exists leads (
  id                   uuid primary key default gen_random_uuid(),
  tenant_id            uuid not null references tenants(id) on delete cascade,
  caller_phone         text not null,
  status               text not null default 'engaging' check (status in
                         ('engaging','qualified','emergency','awaiting_slot','callback_booked',
                          'declined','closed','not_a_lead','voicemail')),
  customer_name        text,
  job_type             text,
  job_description      text,
  suburb               text,
  urgency              text,
  preferred_callback   text,
  in_service_area      boolean,
  photo_urls           text[] not null default '{}',
  action_token         text not null unique default left(replace(gen_random_uuid()::text, '-', ''), 20),
  proposed_slots       timestamptz[],
  callback_at          timestamptz,
  outcome              text check (outcome in ('won','lost')),
  nudged_at            timestamptz,
  tradie_notified_at   timestamptz,
  tradie_reminded_at   timestamptz,
  callback_reminded_at timestamptz,
  outcome_asked_at     timestamptz,
  last_customer_msg_at timestamptz,
  last_bot_msg_at      timestamptz,
  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now()
);
create index if not exists leads_lookup_idx on leads (tenant_id, caller_phone, status);
create index if not exists leads_status_idx on leads (status);

create table if not exists messages (
  id         bigserial primary key,
  lead_id    uuid not null references leads(id) on delete cascade,
  direction  text not null check (direction in ('in','out')),
  body       text,
  media_urls text[] not null default '{}',
  created_at timestamptz not null default now()
);
create index if not exists messages_lead_idx on messages (lead_id, created_at);

-- ---------------------------------------------------------------------
-- 2. Small helpers
-- ---------------------------------------------------------------------

create or replace function _cfg() returns app_config
language sql stable as $$ select * from app_config where id = 1 $$;

-- Escape text for XML (TwiML) and HTML
create or replace function _xml(s text) returns text
language sql immutable as $$
  select replace(replace(replace(replace(replace(coalesce(s, ''),
         '&', '&amp;'), '<', '&lt;'), '>', '&gt;'), '"', '&quot;'), '''', '&apos;')
$$;

-- TwiML <Say> in an Australian voice
create or replace function _say(s text) returns text
language sql immutable as $$
  select '<Say voice="Polly.Olivia-Neural" language="en-AU">' || _xml(s) || '</Say>'
$$;

create or replace function _is_au_mobile(p text) returns boolean
language sql immutable as $$ select coalesce(p ~ '^\+614\d{8}$', false) $$;

create or replace function _local(ts timestamptz, tz text) returns text
language sql stable as $$ select to_char(ts at time zone tz, 'Dy DD Mon, FMHH12:MIam') $$;

-- Action objects that n8n sends through Twilio
create or replace function _sms(p_to text, p_from text, p_body text) returns jsonb
language sql stable as $$
  select jsonb_build_object(
    'type', 'sms', 'to', p_to, 'from', p_from, 'body', p_body,
    'url', 'https://api.twilio.com/2010-04-01/Accounts/' || (_cfg()).twilio_account_sid || '/Messages.json')
$$;

create or replace function _call(p_to text, p_from text, p_twiml text) returns jsonb
language sql stable as $$
  select jsonb_build_object(
    'type', 'call', 'to', p_to, 'from', p_from, 'twiml', p_twiml,
    'url', 'https://api.twilio.com/2010-04-01/Accounts/' || (_cfg()).twilio_account_sid || '/Calls.json')
$$;

-- Links the tradie taps in their SMS
create or replace function _action_url(p_token text, p_action text) returns text
language sql stable as $$
  select (_cfg()).webhook_base_url || '/rl-t-' || (_cfg()).webhook_secret
         || '?t=' || p_token || '&a=' || p_action
$$;

-- Simple mobile-friendly page returned when the tradie taps a link
create or replace function _page(p_title text, p_body text) returns text
language sql immutable as $$
  select '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
      || '<title>' || _xml(p_title) || '</title></head>'
      || '<body style="font-family:system-ui,sans-serif;max-width:480px;margin:40px auto;padding:0 20px;line-height:1.5">'
      || '<h2>' || _xml(p_title) || '</h2><p>' || _xml(p_body) || '</p></body></html>'
$$;

-- Record an outbound customer message
create or replace function _log_out(p_lead uuid, p_body text) returns void
language sql as $$
  insert into messages (lead_id, direction, body) values (p_lead, 'out', p_body);
  update leads set last_bot_msg_at = now(), updated_at = now() where id = p_lead;
$$;

-- The current open conversation with this caller, if any
create or replace function _open_lead(p_tenant uuid, p_phone text) returns leads
language sql stable as $$
  select * from leads
  where tenant_id = p_tenant and caller_phone = p_phone
    and status in ('engaging','qualified','emergency','awaiting_slot','callback_booked')
    and greatest(created_at,
                 coalesce(last_customer_msg_at, created_at),
                 coalesce(last_bot_msg_at, created_at),
                 coalesce(callback_at, created_at)) > now() - interval '3 days'
  order by created_at desc
  limit 1
$$;

-- Is it a sensible hour to send a non-urgent text in this tenant's timezone?
create or replace function _awake(p_tz text) returns boolean
language sql stable as $$
  select extract(hour from now() at time zone p_tz) >= (_cfg()).quiet_end_hour
     and extract(hour from now() at time zone p_tz) <  (_cfg()).quiet_start_hour
$$;

-- Lead summary texted to the tradie
create or replace function _summary(l leads, p_title text, p_with_links boolean default true) returns text
language sql stable as $$
  select p_title || ': ' || coalesce(l.customer_name, '(name not given)') || ' ' || l.caller_phone
      || E'\nJob: ' || coalesce(l.job_type, '?') || coalesce(' - ' || l.job_description, '')
      || E'\nWhere: ' || coalesce(l.suburb, '?')
      || case when l.in_service_area is false then ' (OUTSIDE your area)' else '' end
      || E'\nUrgency: ' || coalesce(l.urgency, '?')
      || E'\nBest time: ' || coalesce(l.preferred_callback, '?')
      || case when cardinality(l.photo_urls) > 0
              then E'\nPhotos received: ' || cardinality(l.photo_urls) else '' end
      || case when p_with_links then
              E'\n\nOffer callback times: ' || _action_url(l.action_token, 'book')
           || E'\nCan''t take it: ' || _action_url(l.action_token, 'decline')
         else '' end
$$;

-- Next free callback slots inside business hours (30 min, spaced 2h apart)
create or replace function _next_slots(p_t tenants, p_n int) returns timestamptz[]
language plpgsql stable as $$
declare
  v_today  date := (now() at time zone p_t.timezone)::date;
  v_day    date;
  v_hours  jsonb;
  v_cursor timestamp;
  v_end    timestamp;
  v_slot   timestamptz;
  v_res    timestamptz[] := '{}';
begin
  for i in 0..13 loop
    v_day   := v_today + i;
    v_hours := p_t.business_hours -> lower(to_char(v_day, 'Dy'));
    continue when v_hours is null or jsonb_typeof(v_hours) <> 'array' or jsonb_array_length(v_hours) <> 2;
    v_cursor := v_day + (v_hours ->> 0)::time;
    v_end    := v_day + (v_hours ->> 1)::time;
    while v_cursor + interval '30 minutes' <= v_end loop
      v_slot := v_cursor at time zone p_t.timezone;
      if v_slot >= now() + interval '1 hour'
         and not exists (select 1 from leads l
                         where l.tenant_id = p_t.id and l.status = 'callback_booked'
                           and l.callback_at > v_slot - interval '30 minutes'
                           and l.callback_at < v_slot + interval '30 minutes') then
        v_res := v_res || v_slot;
        if cardinality(v_res) >= p_n then return v_res; end if;
        v_cursor := v_cursor + interval '2 hours';
      else
        v_cursor := v_cursor + interval '30 minutes';
      end if;
    end loop;
  end loop;
  return v_res;
end $$;

-- ---------------------------------------------------------------------
-- 3. The LLM system prompt (edit wording here, no n8n changes needed)
-- ---------------------------------------------------------------------

create or replace function _system_prompt(p_t tenants, p_max int) returns text
language sql stable as $$
select
  'You are the text-message assistant for ' || p_t.business_name || ', a ' || p_t.trade
  || ' business run by ' || p_t.owner_name || '. A customer called while ' || p_t.owner_name
  || ' was busy on a job. You are texting them to capture the job details so ' || p_t.owner_name
  || ' can call them back.' || E'\n\n'
  || 'Current local time: ' || to_char(now() at time zone p_t.timezone, 'Dy DD Mon YYYY, FMHH12:MIam') || E'\n'
  || 'Service area: ' || coalesce(p_t.service_area_desc, 'not specified') || E'\n'
  || 'Service postcodes: ' || coalesce(nullif(array_to_string(p_t.service_postcodes, ', '), ''), 'not specified') || E'\n'
  || 'Business hours: ' || p_t.business_hours::text || E'\n\n'
  || 'GOAL - collect, through a short friendly text conversation:' || E'\n'
  || '1. What the job is (job_type, plus a one-line job_description)' || E'\n'
  || '2. The suburb where the work is' || E'\n'
  || '3. How urgent it is' || E'\n'
  || '4. Their first name' || E'\n'
  || '5. When suits for a callback' || E'\n\n'
  || 'RULES' || E'\n'
  || '- Ask ONE short question per message. At most 2 sentences and under 300 characters. Plain text, no emoji, no links.' || E'\n'
  || '- Australian English. Friendly, relaxed and professional, never pushy or salesy.' || E'\n'
  || '- Never quote prices, estimates or arrival times, and never promise ' || p_t.owner_name
  || ' can do the job. If asked about cost, say ' || p_t.owner_name || ' will go through it on the callback.' || E'\n'
  || '- If asked, say honestly that you are an automated assistant.' || E'\n'
  || '- Never ask for something the customer has already told you. Combine questions only if the customer seems in a hurry.' || E'\n'
  || '- When you know the job, the suburb and the urgency (name and callback time are nice to have), set status "qualified" '
  || 'and send a short wrap-up saying ' || p_t.owner_name || ' will be in touch soon.' || E'\n'
  || '- You may send at most ' || p_max || ' messages in total. If you reach that, wrap up with status "qualified" regardless.' || E'\n'
  || '- EMERGENCY: if there is a current risk to safety or of serious property damage (for example flooding or a burst pipe, '
  || 'sparking or a burning smell, no power to the whole home, sewage overflowing, someone locked out with a child or pet inside), '
  || 'set status "emergency" and tell them ' || p_t.owner_name || ' is being alerted right now. '
  || 'If there is any danger to life or a fire, tell them to call 000 first. If they smell gas, tell them to call the gas emergency line first.' || E'\n'
  || '- If the message is clearly not a customer enquiry (spam, wrong number, a supplier, a sales pitch), set status "not_a_lead" '
  || 'and either reply briefly and politely or leave next_message empty.' || E'\n'
  || '- Record in_service_area as true, false, or null if unknown. If outside the area, do not turn them away - just record it.' || E'\n'
  || coalesce(E'\nEXTRA INSTRUCTIONS FROM THE BUSINESS OWNER:\n' || p_t.extra_instructions || E'\n', '')
  || E'\nOUTPUT FORMAT\n'
  || 'Return ONLY a JSON object, with no markdown and no other text, using exactly these keys:' || E'\n'
  || '{"fields":{"name":string|null,"job_type":string|null,"job_description":string|null,"suburb":string|null,'
  || '"urgency":"emergency"|"today"|"this_week"|"flexible"|null,"preferred_callback":string|null},'
  || '"in_service_area":true|false|null,"status":"engaging"|"qualified"|"emergency"|"not_a_lead","next_message":string}' || E'\n'
  || '"fields" must contain everything known so far from the whole conversation, not just the latest message.'
$$;

-- ---------------------------------------------------------------------
-- 4. RPC functions called by n8n (each takes one jsonb param "p")
-- ---------------------------------------------------------------------

-- 4a. A diverted (missed) call arrives at the Twilio number.
--     p: {to, from, call_sid}   returns: {twiml, actions[]}
create or replace function fn_intake(p jsonb) returns jsonb
language plpgsql as $$
declare
  c        app_config := _cfg();
  t        tenants;
  v_from   text := nullif(trim(p->>'from'), '');
  v_lead   leads;
  v_reason text;
  v_vm_url text;
  v_opener text;
begin
  select * into t from tenants where twilio_number = p->>'to' and active;
  if not found then
    return jsonb_build_object('twiml',
      '<Response>' || _say('Sorry, this number is not in service.') || '<Hangup/></Response>',
      'actions', '[]'::jsonb);
  end if;

  -- Callers we should NOT text: send them to voicemail instead
  if v_from is null or v_from !~ '^\+\d{8,15}$' then v_reason := 'withheld';
  elsif exists (select 1 from opt_outs where tenant_id = t.id and phone = v_from) then v_reason := 'opted_out';
  elsif exists (select 1 from known_contacts where tenant_id = t.id and phone = v_from) then v_reason := 'known_contact';
  elsif not _is_au_mobile(v_from) then v_reason := 'landline';
  end if;

  if v_reason is not null then
    insert into call_events (tenant_id, caller_phone, call_sid, outcome)
    values (t.id, v_from, p->>'call_sid', 'voicemail:' || v_reason);
    v_vm_url := c.webhook_base_url || '/rl-vm-' || c.webhook_secret
             || '?to=' || replace(t.twilio_number, '+', '%2B')
             || '&from=' || replace(coalesce(v_from, 'unknown'), '+', '%2B');
    return jsonb_build_object('twiml',
      '<Response>'
      || _say('Sorry, ' || t.business_name || ' can''t get to the phone right now. Please leave your name, number and what you need after the beep.')
      || '<Record maxLength="120" playBeep="true" transcribe="true" transcribeCallback="' || _xml(v_vm_url) || '"/>'
      || '</Response>',
      'actions', '[]'::jsonb);
  end if;

  v_lead := _open_lead(t.id, v_from);

  -- Repeat caller with a live conversation: don't re-text, just reassure
  if v_lead.id is not null
     and not (v_lead.status = 'engaging'
              and (v_lead.last_bot_msg_at is null or v_lead.last_bot_msg_at < now() - c.repeat_call_window)) then
    insert into call_events (tenant_id, caller_phone, call_sid, outcome)
    values (t.id, v_from, p->>'call_sid', 'repeat_call');
    return jsonb_build_object('twiml',
      '<Response>'
      || _say('Thanks for calling back. We''ve got your details and ' || t.owner_name || ' will be in touch soon. You can also reply to our text message.')
      || '<Hangup/></Response>',
      'actions', case when v_lead.status in ('qualified','emergency','awaiting_slot','callback_booked')
                      then jsonb_build_array(_sms(t.owner_mobile, t.twilio_number,
                             'FYI: ' || coalesce(v_lead.customer_name, 'a customer') || ' (' || v_from || ') just called again.'))
                      else '[]'::jsonb end);
  end if;

  if v_lead.id is null then
    insert into leads (tenant_id, caller_phone) values (t.id, v_from) returning * into v_lead;
  end if;

  insert into call_events (tenant_id, caller_phone, call_sid, outcome)
  values (t.id, v_from, p->>'call_sid', 'texted');

  v_opener := 'Hi, this is the text assistant for ' || t.business_name
           || '. Sorry we missed your call! What do you need a hand with? (Reply STOP to opt out)';
  perform _log_out(v_lead.id, v_opener);

  return jsonb_build_object('twiml',
    '<Response>'
    || _say('Sorry, ' || t.business_name || ' is busy on a job right now. We''ll send you a text message straight away so we can help.')
    || '<Hangup/></Response>',
    'actions', jsonb_build_array(_sms(v_from, t.twilio_number, v_opener)));
end $$;

-- 4b. Voicemail transcript arrives (landlines, withheld numbers, known contacts).
--     p: {to, from, transcription, status, recording_url}   returns: {actions[]}
create or replace function fn_voicemail(p jsonb) returns jsonb
language plpgsql as $$
declare
  t      tenants;
  v_from text := nullif(nullif(trim(p->>'from'), ''), 'unknown');
  v_text text := nullif(trim(p->>'transcription'), '');
begin
  select * into t from tenants where twilio_number = p->>'to' and active;
  if not found then return jsonb_build_object('actions', '[]'::jsonb); end if;

  insert into leads (tenant_id, caller_phone, status, job_description)
  values (t.id, coalesce(v_from, 'withheld'), 'voicemail', left(v_text, 500));

  return jsonb_build_object('actions', jsonb_build_array(_sms(t.owner_mobile, t.twilio_number,
    'Voicemail from ' || coalesce(v_from, 'a withheld number') || E':\n"'
    || coalesce(left(v_text, 600), '(no transcript - listen in the Twilio console)') || '"')));
end $$;

-- 4c. Customer texts the Twilio number.
--     p: {to, from, body, media_urls[]}
--     returns: {needs_llm, lead_id, llm_request, actions[]}
create or replace function fn_inbound_sms(p jsonb) returns jsonb
language plpgsql as $$
declare
  c            app_config := _cfg();
  t            tenants;
  v_from       text := trim(p->>'from');
  v_body       text := trim(coalesce(p->>'body', ''));
  v_kw         text;
  v_media      text[];
  v_lead       leads;
  v_n          int;
  v_slot       timestamptz;
  v_msg        text;
  v_bot_count  int;
  v_transcript text;
  v_none       jsonb := jsonb_build_object('needs_llm', false, 'actions', '[]'::jsonb);
begin
  select * into t from tenants where twilio_number = p->>'to' and active;
  if not found then return v_none; end if;

  v_kw    := upper(regexp_replace(v_body, '[^A-Za-z]', '', 'g'));
  v_media := coalesce(array(select jsonb_array_elements_text(coalesce(p->'media_urls', '[]'::jsonb))), '{}');

  -- Opt-out / opt-in keywords
  if v_kw in ('STOP','STOPALL','UNSUBSCRIBE','CANCEL','END','QUIT','OPTOUT') then
    insert into opt_outs (tenant_id, phone) values (t.id, v_from) on conflict do nothing;
    update leads set status = 'closed', updated_at = now()
    where tenant_id = t.id and caller_phone = v_from
      and status in ('engaging','qualified','emergency','awaiting_slot','callback_booked');
    return jsonb_build_object('needs_llm', false, 'actions', jsonb_build_array(_sms(v_from, t.twilio_number,
      'You''ve been unsubscribed from ' || t.business_name || ' text messages. Reply START to opt back in.')));
  end if;
  if v_kw in ('START','UNSTOP') then
    delete from opt_outs where tenant_id = t.id and phone = v_from;
    return jsonb_build_object('needs_llm', false, 'actions', jsonb_build_array(_sms(v_from, t.twilio_number,
      'You''re opted back in to texts from ' || t.business_name || '.')));
  end if;
  if exists (select 1 from opt_outs where tenant_id = t.id and phone = v_from) then
    return v_none;
  end if;

  v_lead := _open_lead(t.id, v_from);
  if v_lead.id is null then
    -- Ignore numbers we recently marked as not a lead (spam, wrong number)
    if exists (select 1 from leads where tenant_id = t.id and caller_phone = v_from
               and status = 'not_a_lead' and updated_at > now() - interval '3 days') then
      return v_none;
    end if;
    insert into leads (tenant_id, caller_phone) values (t.id, v_from) returning * into v_lead;
  end if;

  insert into messages (lead_id, direction, body, media_urls) values (v_lead.id, 'in', v_body, v_media);
  update leads set last_customer_msg_at = now(), photo_urls = photo_urls || v_media, updated_at = now()
  where id = v_lead.id returning * into v_lead;

  -- Customer is picking a callback slot
  if v_lead.status = 'awaiting_slot' then
    if v_body ~ '^[1-9]$' then
      v_n := v_body::int;
      if v_n <= coalesce(cardinality(v_lead.proposed_slots), 0) then
        v_slot := v_lead.proposed_slots[v_n];
        update leads set status = 'callback_booked', callback_at = v_slot, updated_at = now()
        where id = v_lead.id returning * into v_lead;
        v_msg := 'Done! ' || t.owner_name || ' will call you on ' || _local(v_slot, t.timezone) || '. Talk then.';
        perform _log_out(v_lead.id, v_msg);
        return jsonb_build_object('needs_llm', false, 'actions', jsonb_build_array(
          _sms(v_from, t.twilio_number, v_msg),
          _sms(t.owner_mobile, t.twilio_number, _summary(v_lead, 'Callback booked for ' || _local(v_slot, t.timezone), false))));
      end if;
    end if;
    -- Anything else: pass it to the tradie
    v_msg := 'Thanks, I''ve passed that on to ' || t.owner_name || '.';
    perform _log_out(v_lead.id, v_msg);
    return jsonb_build_object('needs_llm', false, 'actions', jsonb_build_array(
      _sms(v_from, t.twilio_number, v_msg),
      _sms(t.owner_mobile, t.twilio_number,
        coalesce(v_lead.customer_name, v_from) || ' (' || v_from || ') replied about callback times: "' || left(v_body, 300) || '"')));
  end if;

  -- Already handed to the tradie: forward, ack at most once an hour
  if v_lead.status in ('qualified','emergency','callback_booked') then
    v_msg := 'Thanks, I''ve passed that on to ' || t.owner_name || '.';
    if v_lead.last_bot_msg_at is null or v_lead.last_bot_msg_at < now() - interval '1 hour' then
      perform _log_out(v_lead.id, v_msg);
      return jsonb_build_object('needs_llm', false, 'actions', jsonb_build_array(
        _sms(v_from, t.twilio_number, v_msg),
        _sms(t.owner_mobile, t.twilio_number,
          'Message from ' || coalesce(v_lead.customer_name, v_from) || ' (' || v_from || '): "' || left(v_body, 300) || '"'
          || case when cardinality(v_media) > 0 then ' [+' || cardinality(v_media) || ' photo(s)]' else '' end)));
    end if;
    return jsonb_build_object('needs_llm', false, 'actions', jsonb_build_array(
      _sms(t.owner_mobile, t.twilio_number,
        'Message from ' || coalesce(v_lead.customer_name, v_from) || ' (' || v_from || '): "' || left(v_body, 300) || '"'
        || case when cardinality(v_media) > 0 then ' [+' || cardinality(v_media) || ' photo(s)]' else '' end)));
  end if;

  -- Still qualifying: hand the conversation to the LLM
  select count(*) into v_bot_count from messages where lead_id = v_lead.id and direction = 'out';
  select string_agg(
           case direction when 'in' then 'Customer: ' else 'You: ' end
           || coalesce(nullif(body, ''), '(no text)')
           || case when cardinality(media_urls) > 0 then ' [sent ' || cardinality(media_urls) || ' photo(s)]' else '' end,
           E'\n' order by created_at, id)
    into v_transcript
    from messages where lead_id = v_lead.id;

  return jsonb_build_object(
    'needs_llm', true,
    'lead_id', v_lead.id,
    'actions', '[]'::jsonb,
    'llm_request', jsonb_build_object(
      'model', c.llm_model,
      'max_tokens', 600,
      'system', _system_prompt(t, c.max_bot_messages),
      'messages', jsonb_build_array(jsonb_build_object(
        'role', 'user',
        'content', 'Conversation so far:' || E'\n' || v_transcript || E'\n\n'
                || 'You have sent ' || v_bot_count || ' message(s). Respond with the JSON object only.'))));
end $$;

-- 4d. Apply the LLM's answer.
--     p: {lead_id, result (object or null), raw}   returns: {actions[]}
create or replace function fn_apply_llm(p jsonb) returns jsonb
language plpgsql as $$
declare
  c         app_config := _cfg();
  v_lead    leads;
  t         tenants;
  r         jsonb := p->'result';
  f         jsonb;
  v_status  text;
  v_next    text;
  v_count   int;
  v_actions jsonb := '[]'::jsonb;
begin
  select * into v_lead from leads where id = (p->>'lead_id')::uuid;
  if not found or v_lead.status <> 'engaging' then
    return jsonb_build_object('actions', '[]'::jsonb);   -- race guard
  end if;
  select * into t from tenants where id = v_lead.tenant_id;

  if r is null or jsonb_typeof(r) <> 'object' then
    -- LLM failed or returned junk: fail safe, hand straight to the tradie
    v_status := 'qualified';
    v_next   := 'Thanks for that! I''ve passed your details to ' || t.owner_name || ', who''ll get back to you shortly.';
    update leads set job_description = coalesce(job_description,
             (select left(string_agg(body, ' / ' order by created_at), 300)
                from messages where lead_id = v_lead.id and direction = 'in'))
    where id = v_lead.id;
  else
    f := coalesce(r->'fields', '{}'::jsonb);
    update leads set
      customer_name      = coalesce(nullif(trim(f->>'name'), ''), customer_name),
      job_type           = coalesce(nullif(trim(f->>'job_type'), ''), job_type),
      job_description    = coalesce(nullif(trim(f->>'job_description'), ''), job_description),
      suburb             = coalesce(nullif(trim(f->>'suburb'), ''), suburb),
      urgency            = case when f->>'urgency' in ('emergency','today','this_week','flexible')
                                then f->>'urgency' else urgency end,
      preferred_callback = coalesce(nullif(trim(f->>'preferred_callback'), ''), preferred_callback),
      in_service_area    = case when jsonb_typeof(r->'in_service_area') = 'boolean'
                                then (r->>'in_service_area')::boolean else in_service_area end,
      updated_at         = now()
    where id = v_lead.id;
    v_status := case when r->>'status' in ('engaging','qualified','emergency','not_a_lead')
                     then r->>'status' else 'engaging' end;
    v_next   := left(trim(coalesce(r->>'next_message', '')), 480);
  end if;

  select count(*) into v_count from messages where lead_id = v_lead.id and direction = 'out';
  if v_status = 'engaging' and (v_count >= c.max_bot_messages or v_next = '') then
    v_status := 'qualified';
    v_next   := 'Thanks, that''s everything I need. ' || t.owner_name || ' will be in touch soon.';
  end if;

  if v_next <> '' then
    v_actions := v_actions || jsonb_build_array(_sms(v_lead.caller_phone, t.twilio_number, v_next));
    perform _log_out(v_lead.id, v_next);
  end if;

  update leads set status = v_status,
                   tradie_notified_at = case when v_status in ('qualified','emergency') then now() else tradie_notified_at end,
                   updated_at = now()
  where id = v_lead.id returning * into v_lead;

  if v_status = 'qualified' then
    v_actions := v_actions || jsonb_build_array(_sms(t.owner_mobile, t.twilio_number, _summary(v_lead, 'New lead')));
  elsif v_status = 'emergency' then
    v_actions := v_actions || jsonb_build_array(
      _sms(t.owner_mobile, t.twilio_number, _summary(v_lead, 'URGENT - possible emergency')),
      _call(t.owner_mobile, t.twilio_number,
        '<Response>'
        || _say('Urgent job alert from your text assistant. ' || coalesce(v_lead.customer_name, 'A customer')
                || ' in ' || coalesce(v_lead.suburb, 'an unknown suburb') || ' needs help now. Check your text messages for details.')
        || '<Pause length="1"/>'
        || _say('Again, urgent job alert. Check your text messages.')
        || '</Response>'));
  end if;

  return jsonb_build_object('actions', v_actions);
end $$;

-- 4e. Tradie taps a link in their SMS.
--     p: {t (token), a (book|decline|won|lost)}   returns: {html, actions[]}
create or replace function fn_tradie_action(p jsonb) returns jsonb
language plpgsql as $$
declare
  v_lead    leads;
  t         tenants;
  v_slots   timestamptz[];
  v_msg     text;
  v_who     text;
begin
  select * into v_lead from leads where action_token = p->>'t';
  if not found then
    return jsonb_build_object('html', _page('Link not valid', 'This link has expired or is not valid.'), 'actions', '[]'::jsonb);
  end if;
  select * into t from tenants where id = v_lead.tenant_id;
  v_who := coalesce(v_lead.customer_name, v_lead.caller_phone);

  case p->>'a'
  when 'book' then
    if v_lead.status in ('awaiting_slot','callback_booked') then
      return jsonb_build_object('html', _page('Already done', 'Callback times have already been sent to ' || v_who || '.'), 'actions', '[]'::jsonb);
    elsif v_lead.status not in ('qualified','emergency') then
      return jsonb_build_object('html', _page('Lead closed', 'This lead is closed. You can still call ' || v_who || ' on ' || v_lead.caller_phone || '.'), 'actions', '[]'::jsonb);
    end if;
    v_slots := _next_slots(t, 3);
    if coalesce(cardinality(v_slots), 0) = 0 then
      return jsonb_build_object('html', _page('No free times', 'No free times in your business hours over the next two weeks. Call ' || v_who || ' directly on ' || v_lead.caller_phone || '.'), 'actions', '[]'::jsonb);
    end if;
    v_msg := 'Hi' || coalesce(' ' || v_lead.customer_name, '') || ', ' || t.owner_name || ' can call you back at:';
    for i in 1..cardinality(v_slots) loop
      v_msg := v_msg || E'\n' || i || ') ' || _local(v_slots[i], t.timezone);
    end loop;
    v_msg := v_msg || E'\nReply with the number that suits, or tell us a better time.';
    update leads set status = 'awaiting_slot', proposed_slots = v_slots, updated_at = now() where id = v_lead.id;
    perform _log_out(v_lead.id, v_msg);
    return jsonb_build_object(
      'html', _page('Times offered', 'We''ve texted ' || v_who || ' ' || cardinality(v_slots) || ' callback times. You''ll get a text when they pick one.'),
      'actions', jsonb_build_array(_sms(v_lead.caller_phone, t.twilio_number, v_msg)));

  when 'decline' then
    if v_lead.status in ('declined','closed','not_a_lead') then
      return jsonb_build_object('html', _page('Already closed', 'This lead is already closed.'), 'actions', '[]'::jsonb);
    end if;
    v_msg := 'Thanks for contacting ' || t.business_name || '. Unfortunately ' || t.owner_name
          || ' can''t take this one on right now. Sorry we couldn''t help this time!';
    update leads set status = 'declined', updated_at = now() where id = v_lead.id;
    perform _log_out(v_lead.id, v_msg);
    return jsonb_build_object('html', _page('Declined', 'We''ve politely let ' || v_who || ' know.'),
      'actions', jsonb_build_array(_sms(v_lead.caller_phone, t.twilio_number, v_msg)));

  when 'won', 'lost' then
    update leads set outcome = p->>'a', updated_at = now() where id = v_lead.id;
    return jsonb_build_object('html', _page('Thanks!', 'Recorded the ' || v_who || ' job as ' || (p->>'a') || '.'), 'actions', '[]'::jsonb);

  else
    return jsonb_build_object('html', _page('Unknown action', 'That link is not valid.'), 'actions', '[]'::jsonb);
  end case;
end $$;

-- 4f. Scheduled housekeeping (run every 5 minutes).
--     p: {}   returns: {actions[]}
create or replace function fn_due_actions(p jsonb default '{}'::jsonb) returns jsonb
language plpgsql as $$
declare
  c         app_config := _cfg();
  r         record;
  v_msg     text;
  v_actions jsonb := '[]'::jsonb;
begin
  -- 1. One gentle nudge to customers who went quiet
  for r in
    update leads l set nudged_at = now(), updated_at = now()
    from tenants tn
    where tn.id = l.tenant_id and l.status = 'engaging' and l.nudged_at is null
      and l.last_bot_msg_at < now() - c.nudge_after
      and l.last_bot_msg_at > now() - c.close_after
      and (l.last_customer_msg_at is null or l.last_customer_msg_at < l.last_bot_msg_at)
      and _awake(tn.timezone)
      and not exists (select 1 from opt_outs o where o.tenant_id = tn.id and o.phone = l.caller_phone)
    returning l.id, l.caller_phone, tn.twilio_number, tn.owner_name
  loop
    v_msg := 'Just checking in - are you still after a hand? Reply any time and we''ll get ' || r.owner_name || ' onto it.';
    perform _log_out(r.id, v_msg);
    v_actions := v_actions || jsonb_build_array(_sms(r.caller_phone, r.twilio_number, v_msg));
  end loop;

  -- 2. Partial leads: customer replied at least once, then stopped after the nudge
  for r in
    update leads l set status = 'qualified', tradie_notified_at = now(), updated_at = now()
    from tenants tn
    where tn.id = l.tenant_id and l.status = 'engaging'
      and l.last_customer_msg_at is not null
      and l.nudged_at < now() - c.nudge_after
      and l.last_customer_msg_at < l.nudged_at
      and _awake(tn.timezone)
    returning l.*, tn.owner_mobile, tn.twilio_number
  loop
    v_actions := v_actions || jsonb_build_array(_sms(r.owner_mobile, r.twilio_number,
      _summary((select x from leads x where x.id = r.id), 'Partial lead (stopped replying)')));
  end loop;

  -- 3. Close conversations where the customer never replied
  update leads set status = 'closed', updated_at = now()
  where status = 'engaging' and last_customer_msg_at is null and created_at < now() - c.close_after;

  -- 4. Customer never picked a callback time
  for r in
    update leads l set status = 'qualified', tradie_reminded_at = now(), updated_at = now()
    from tenants tn
    where tn.id = l.tenant_id and l.status = 'awaiting_slot'
      and l.last_bot_msg_at < now() - c.slot_pick_timeout
      and coalesce(l.last_customer_msg_at, l.created_at) < l.last_bot_msg_at
      and _awake(tn.timezone)
    returning l.*, tn.owner_mobile, tn.twilio_number
  loop
    v_actions := v_actions || jsonb_build_array(_sms(r.owner_mobile, r.twilio_number,
      coalesce(r.customer_name, r.caller_phone) || ' hasn''t picked a callback time. Best to call them directly on ' || r.caller_phone || '.'));
  end loop;

  -- 5. Remind the tradie about qualified leads they haven't actioned
  for r in
    update leads l set tradie_reminded_at = now(), updated_at = now()
    from tenants tn
    where tn.id = l.tenant_id and l.status = 'qualified' and l.tradie_reminded_at is null
      and l.tradie_notified_at < now() - c.tradie_reminder_after
      and _awake(tn.timezone)
    returning l.*, tn.owner_mobile, tn.twilio_number
  loop
    v_actions := v_actions || jsonb_build_array(_sms(r.owner_mobile, r.twilio_number,
      'Reminder: ' || coalesce(r.customer_name, 'a customer') || ' (' || r.caller_phone || ') is waiting to hear back about '
      || coalesce(r.job_type, 'a job') || E'.\nOffer callback times: ' || _action_url(r.action_token, 'book')));
  end loop;

  -- 6. 15-minute heads-up before a booked callback
  for r in
    update leads l set callback_reminded_at = now(), updated_at = now()
    from tenants tn
    where tn.id = l.tenant_id and l.status = 'callback_booked' and l.callback_reminded_at is null
      and l.callback_at between now() and now() + interval '15 minutes'
    returning l.*, tn.owner_mobile, tn.twilio_number
  loop
    v_actions := v_actions || jsonb_build_array(_sms(r.owner_mobile, r.twilio_number,
      'In about 15 min: call ' || coalesce(r.customer_name, 'the customer') || ' on ' || r.caller_phone
      || ' about ' || coalesce(r.job_type, 'their job') || coalesce(' in ' || r.suburb, '') || '.'));
  end loop;

  -- 7. Two days later: ask whether the job was won (this is your ROI data)
  for r in
    update leads l set outcome_asked_at = now(), updated_at = now()
    from tenants tn
    where tn.id = l.tenant_id and l.status in ('qualified','emergency','callback_booked')
      and l.outcome is null and l.outcome_asked_at is null
      and coalesce(l.callback_at, l.tradie_notified_at) < now() - interval '2 days'
      and _awake(tn.timezone)
    returning l.*, tn.owner_mobile, tn.twilio_number
  loop
    v_actions := v_actions || jsonb_build_array(_sms(r.owner_mobile, r.twilio_number,
      'Quick one: did you win the job with ' || coalesce(r.customer_name, r.caller_phone) || coalesce(' in ' || r.suburb, '') || '?'
      || E'\nWon: ' || _action_url(r.action_token, 'won')
      || E'\nLost: ' || _action_url(r.action_token, 'lost')));
  end loop;

  return jsonb_build_object('actions', v_actions);
end $$;

-- ---------------------------------------------------------------------
-- 5. Reporting
-- ---------------------------------------------------------------------

create or replace view v_funnel_weekly as
with calls as (
  select tenant_id, date_trunc('week', created_at)::date as week_start,
         count(*) as missed_calls,
         count(*) filter (where outcome = 'texted') as texted,
         count(*) filter (where outcome like 'voicemail:%') as sent_to_voicemail
  from call_events group by 1, 2
), lw as (
  select tenant_id, date_trunc('week', created_at)::date as week_start,
         count(*) filter (where status <> 'voicemail' and last_customer_msg_at is not null) as replied,
         count(*) filter (where tradie_notified_at is not null) as qualified,
         count(*) filter (where status = 'emergency' or urgency = 'emergency') as emergencies,
         count(*) filter (where callback_at is not null) as callbacks_booked,
         count(*) filter (where outcome = 'won') as won,
         count(*) filter (where outcome = 'lost') as lost
  from leads group by 1, 2
)
select tn.business_name,
       coalesce(calls.week_start, lw.week_start) as week_start,
       coalesce(missed_calls, 0) as missed_calls,
       coalesce(texted, 0) as texted,
       coalesce(sent_to_voicemail, 0) as sent_to_voicemail,
       coalesce(replied, 0) as replied,
       coalesce(qualified, 0) as qualified,
       coalesce(emergencies, 0) as emergencies,
       coalesce(callbacks_booked, 0) as callbacks_booked,
       coalesce(won, 0) as won,
       coalesce(lost, 0) as lost
from calls
full join lw on lw.tenant_id = calls.tenant_id and lw.week_start = calls.week_start
join tenants tn on tn.id = coalesce(calls.tenant_id, lw.tenant_id)
order by week_start desc, business_name;

-- ---------------------------------------------------------------------
-- 6. Security: lock everything down to the service_role key
-- ---------------------------------------------------------------------

alter table app_config     enable row level security;
alter table tenants        enable row level security;
alter table known_contacts enable row level security;
alter table opt_outs       enable row level security;
alter table call_events    enable row level security;
alter table leads          enable row level security;
alter table messages       enable row level security;

do $$
declare f record;
begin
  for f in
    select p.oid::regprocedure as sig
    from pg_proc p join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public' and (p.proname like 'fn\_%' or p.proname like '\_%')
  loop
    execute format('revoke all on function %s from public, anon, authenticated', f.sig);
    execute format('grant execute on function %s to service_role', f.sig);
  end loop;
end $$;

revoke all on v_funnel_weekly from anon, authenticated;
